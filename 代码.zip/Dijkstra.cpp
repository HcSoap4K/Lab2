#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <queue>
using namespace std;
const int N = 1e3 + 10;
const int INF = 0x3f3f3f3f;
int n, m;  // 表示点数和边数

// 链式前向星存图
struct Edge {
    int next, to, dis;
} edge[N];
int num_edge;
int head[N];
void add_edge(int from, int to, int dis) {
    edge[num_edge].next = head[from];
    edge[num_edge].to = to;
    edge[num_edge].dis = dis;
    head[from] = num_edge++;
}

struct Node {
    int id, dis;
    Node() {}
    Node(int id, int dis) : id(id), dis(dis) {}
    bool friend operator<(const Node& a, const Node& b) {
        return a.dis > b.dis;
    }
};
int dis[N];
bool done[N];
void Dijkstra(int s, int t) {
    priority_queue<Node> q;
    memset(dis, INF, sizeof dis);
    memset(done, false, sizeof done);
    q.push(Node(s, dis[s] = 0));
    while (!q.empty()) {
        Node u = q.top();
        q.pop();
        if (done[u.id])
            continue;
        done[u.id] = true;
        for (int i = head[u.id]; i != -1; i = edge[i].next) {
            Edge v = edge[i];
            if (done[v.to])
                continue;
            if (dis[v.to] > u.dis + v.dis) {
                dis[v.to] = u.dis + v.dis;
                q.push(Node(v.to, dis[v.to]));
            }
        }
    }
}
int main() {
    scanf("%d%d", &n, &m);
    // 初始化前向星
    num_edge = 0;
    memset(head, -1, sizeof head);

    for (int i = 1; i <= m; ++i) {
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        add_edge(u, v, w);
    }
    Dijkstra(1, n);
    printf("%d\n", dis[n]);
    return 0;
}