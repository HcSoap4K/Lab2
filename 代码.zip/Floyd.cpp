#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
const int N = 1e3 + 10;
const int INF = 0x3f3f3f3f;
int n, m;      // 表示点数和边数
int mp[N][N];  // 邻接矩阵存图
void Floyd() {
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            if (mp[i][k] == INF)  // 若点i到点k没有边，则直接跳过循环
                continue;
            for (int j = 1; j <= n; j++)
                mp[i][j] = min(mp[i][j], mp[i][k] + mp[k][j]);
        }
    }
}
int main() {
    scanf("%d%d", &n, &m);
    memset(mp, INF, sizeof mp);
    for (int i = 1; i <= n; ++i)  // 点到本身的距离为0
        mp[i][i] = 0;
    for (int i = 1; i <= m; ++i) {
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        mp[u][v] = w;
    }
    Floyd();
    printf("%d\n", mp[1][n]);
    return 0;
}